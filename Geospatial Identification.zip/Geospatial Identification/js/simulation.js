var reload = document.getElementById("reload");
reload.style.display = 'none';

// Turf.js function which returns a boolean if a point lies within a area/polygon
function isPointWithinArea(point, area){
return turf.booleanPointInPolygon(point, area);
}

// Creating a polygon for turf using area A's coordinates
var areaA = turf.polygon([[
            [24.97, 23],
            [71.84, 8],
            [108.88, 8],
            [95, 42.2],
            [30, 43],
            [24.97, 23]
            ]]);

// Creating a polygon for turf using area B's coordinates
var areaB = turf.polygon([[
            [60.67, 9.5],
            [95.78, 6],
            [140, 6],
            [140, 10],
            [135, 20],
            [60.67, 20],
            [60.67, 9.5]
            ]]);

function simulate(){

var button = document.getElementById("button");
button.style.display = 'none';

// Plotting areas with moving point
Plotly.plot('plot', [
    {
        y:[30],
        mode: 'lines',
        name: 'moving point',
        line: {
            dash: 'dot',
            width: 4
        }
    },
    // (x,y) coordinates forming a polygon of area A
    {
        x: [24.97,71.84,108.88,95,30,24.97],
        y: [23.0, 8.0, 8.0, 42.2, 43.0, 23.0], 
        type: 'line',
        name: 'Area - A'
    },
    // (x,y) coordinates forming a polygon of area B
    {
        x: [60.67, 95.78, 140, 140, 135, 60.67, 60.67],
        y: [9.5, 6.0, 6.0, 10, 20, 20, 9.5], 
        type: 'line',
        name: 'Area - B'
    },
    {
        x: [60],
        y: [38], 
        mode: 'text',
        text: ['Area A'],
        showlegend: false,
        textfont: {
            size: 20
        }
    },
    {
        x: [120],
        y: [10], 
        mode: 'text',
        text: ['Area B'],
        showlegend: false,
        textfont: {
            size: 20
        }
    },
    {
        x: [85],
        y: [11], 
        mode: 'text',
        text: ['overlapped region'],
        showlegend: false,
        textfont: {
            size: 15
        }
    },

], 
    // Fixing the range axes for Plotly to draw
    {
    xaxis: {range: [0, 150]},
    yaxis: {range: [0, 50]}
    }
);

var count = 0;

console.log("journey started..!!");
var interval = setInterval(function(){
    var yVal;
    count++;

    if(count < 65){
        yVal = 30;
    } else if (count == 145){
        console.log("journey stopped..!!");
        clearInterval(interval);
        reload.style.display = 'block';
        return;
    } else{
        yVal = 15;
    }

    //making use of the above plot to simulate moving point
    Plotly.extendTraces('plot', { 
                y: [[yVal]]}, 
                [0]);

    //creating a coordinate point using turf
    var point = turf.point([count,yVal]);

    var isWithinAreaA = isPointWithinArea(point, areaA);
    var isWithinAreaB = isPointWithinArea(point, areaB);

    if(isWithinAreaA && isWithinAreaB){
        console.log("Within area A and B");
    } else if ( isWithinAreaA ){
        console.log("Within area A");
    } else if ( isWithinAreaB ){
        console.log("Within area B");
    } else{
        console.log("Outside area A and B");
    }
}, 150);
}
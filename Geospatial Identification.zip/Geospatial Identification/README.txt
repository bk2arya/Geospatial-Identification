Geospatial Identification:

This demo helps to identify the area in which a given point resides.

Turf.js is used to create two polygons representing area A and area B with a portion overlapping.
Plotly.js is used to plot the activity of a moving point and above mentioned areas.

Folder contents:
1. js
	a. plotly.min.js	- provided by Plotly
	b. turf.min.js		- provided by Turfjs.org
	c. simulation.js*	- contains the simulation code

2. home.html - bound with simulation.js

NOTE:
1. * - files created by me.
2. Plotly and Turf is also available as an npm packages.
3. For indepth explaination on advanced geospatial analysis, please visit website: https://turfjs.org